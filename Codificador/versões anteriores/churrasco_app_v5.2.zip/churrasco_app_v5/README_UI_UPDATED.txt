UI integrated with backend bridge. Backend calls are attempted via reflection in ui.swing.backend.UIBackendBridge.
Uploads are copied to resources/uploads when using the 'Registrar Compra' button.
Run ui.swing.MainSwingLauncher as main class in IntelliJ.
