package com.churrascoapp.model;

import java.util.UUID;

public class Churrasco {
    private UUID id;
    private UUID criadorId; // ID do usuário que criou o churrasco
    private String titulo;
    private String data; // exemplo: "2025-05-22"
    private String hora; // exemplo: "14:30"
    private String local;
    private String tipo; // exemplo: "Apenas Churrasco"
    private String pix;  // chave pix opcional
    private double precoParticipante;
    private String descricao;

    public Churrasco() {}

    public Churrasco(UUID id, String titulo, String data, String hora, String local,
                     String tipo, String pix, double precoParticipante, String descricao) {
        this.id = id;
        this.titulo = titulo;
        this.data = data;
        this.hora = hora;
        this.local = local;
        this.tipo = tipo;
        this.pix = pix;
        this.precoParticipante = precoParticipante;
        this.descricao = descricao;
    }

    public Churrasco(UUID id, UUID criadorId, String titulo, String data, String hora, String local,
                     String tipo, String pix, double precoParticipante, String descricao) {
        this.id = id;
        this.criadorId = criadorId;
        this.titulo = titulo;
        this.data = data;
        this.hora = hora;
        this.local = local;
        this.tipo = tipo;
        this.pix = pix;
        this.precoParticipante = precoParticipante;
        this.descricao = descricao;
    }

    // Getters e setters
    public UUID getId() { return id; }
    public void setId(UUID id) { this.id = id; }

    public UUID getCriadorId() { return criadorId; }
    public void setCriadorId(UUID criadorId) { this.criadorId = criadorId; }

    public String getTitulo() { return titulo; }
    public void setTitulo(String titulo) { this.titulo = titulo; }

    public String getData() { return data; }
    public void setData(String data) { this.data = data; }

    public String getHora() { return hora; }
    public void setHora(String hora) { this.hora = hora; }

    public String getLocal() { return local; }
    public void setLocal(String local) { this.local = local; }

    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }

    public String getPix() { return pix; }
    public void setPix(String pix) { this.pix = pix; }

    public double getPrecoParticipante() { return precoParticipante; }
    public void setPrecoParticipante(double precoParticipante) { this.precoParticipante = precoParticipante; }

    public String getDescricao() { return descricao; }
    public void setDescricao(String descricao) { this.descricao = descricao; }

    // CSV
    public String toCSV() {
        return String.join(";",
                id.toString(), 
                criadorId != null ? criadorId.toString() : "",
                titulo, data, hora, local, tipo, pix,
                String.valueOf(precoParticipante),
                descricao == null ? "" : descricao
        );
    }

    public static Churrasco fromCSV(String line) {
        if (line == null || line.trim().isEmpty()) return null;
        
        String[] p = line.split(";", -1);
        if (p.length < 9) {
            // Tenta formato antigo sem criadorId (8 campos)
            if (p.length >= 8) {
                try {
                    return new Churrasco(
                            UUID.fromString(p[0]), 
                            null, // criadorId
                            p[1], // titulo
                            p[2], // data
                            p[3], // hora
                            p[4], // local
                            p[5], // tipo
                            p[6], // pix
                            Double.parseDouble(p[7]), // precoParticipante
                            p.length > 8 ? p[8] : "" // descricao
                    );
                } catch (Exception e) {
                    System.err.println("Erro ao parsear churrasco (formato antigo): " + line + " - " + e.getMessage());
                    return null;
                }
            }
            return null;
        }
        
        UUID criadorId = null;
        int offset = 0;
        
        // Detecta formato: se p[1] é UUID válido e não vazio, então é formato novo com criadorId
        if (p.length >= 10 && p[1] != null && !p[1].trim().isEmpty()) {
            try {
                UUID.fromString(p[1]);
                // Formato novo: id;criadorId;titulo;data;hora;local;tipo;pix;precoParticipante;descricao
                criadorId = UUID.fromString(p[1]);
                offset = 1;
            } catch (Exception ignored) {
                // Não é UUID válido, então é formato antigo
                offset = 0;
            }
        } else {
            // Formato antigo: id;titulo;data;hora;local;tipo;pix;precoParticipante;descricao
            offset = 0;
        }
        
        try {
            UUID id = UUID.fromString(p[0]);
            if (id == null) {
                System.err.println("ID inválido no churrasco: " + p[0]);
                return null;
            }
            
            return new Churrasco(
                    id, 
                    criadorId,
                    p[1 + offset] != null ? p[1 + offset] : "", // titulo
                    p[2 + offset] != null ? p[2 + offset] : "", // data
                    p[3 + offset] != null ? p[3 + offset] : "", // hora
                    p[4 + offset] != null ? p[4 + offset] : "", // local
                    p[5 + offset] != null ? p[5 + offset] : "", // tipo
                    p[6 + offset] != null ? p[6 + offset] : "", // pix
                    Double.parseDouble(p[7 + offset] != null && !p[7 + offset].isEmpty() ? p[7 + offset] : "0"), // precoParticipante
                    p.length > (8 + offset) && p[8 + offset] != null ? p[8 + offset] : "" // descricao
            );
        } catch (Exception e) {
            System.err.println("Erro ao parsear churrasco: " + line + " - " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }
}

