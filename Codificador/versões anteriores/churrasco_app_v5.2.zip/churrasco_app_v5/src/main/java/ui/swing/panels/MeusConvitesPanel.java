package ui.swing.panels;

import com.churrascoapp.app.AppContext;
import com.churrascoapp.controller.ConviteController;
import com.churrascoapp.model.Convite;
import com.churrascoapp.model.Usuario;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class MeusConvitesPanel extends JPanel {

    private final Usuario usuario;
    private final ConviteController conviteController;

    private JTable table;
    private DefaultTableModel model;

    public MeusConvitesPanel(Usuario usuario) {
        this.usuario = usuario;
        this.conviteController = AppContext.get().convites();

        setLayout(new BorderLayout(8,8));

        JButton atualizarBtn = new JButton("Atualizar");
        JButton aceitarBtn   = new JButton("Aceitar Convite");
        JButton recusarBtn   = new JButton("Recusar Convite");

        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT));
        top.add(atualizarBtn);
        top.add(aceitarBtn);
        top.add(recusarBtn);

        add(top, BorderLayout.NORTH);

        model = new DefaultTableModel(
                new String[]{"ID", "Churrasco", "Status", "Mensagem"}, 0
        ) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(model);

        add(new JScrollPane(table), BorderLayout.CENTER);

        atualizarBtn.addActionListener(e -> carregar());
        aceitarBtn.addActionListener(e -> aceitar());
        recusarBtn.addActionListener(e -> recusar());

        carregar();
    }

    private void carregar() {
        model.setRowCount(0);

        // >>>>>>> TRATAMENTO DO ID NULO AQUI <<<<<<<<
        if (usuario.getId() == null) {
            JOptionPane.showMessageDialog(
                    this,
                    "Seu usuário não possui ID cadastrado no sistema.\n" +
                            "Por isso não é possível localizar convites automaticamente.\n\n" +
                            "Se isso for para TCC, você pode:\n" +
                            "- Ajustar o cadastro de usuários para salvar um UUID;\n" +
                            "- Ou alimentar o CSV de usuários com um ID para cada linha.",
                    "ID do usuário ausente",
                    JOptionPane.INFORMATION_MESSAGE
            );
            return;
        }

        List<Convite> lista =
                conviteController.listarConvitesRecebidos(usuario.getId().toString());

        for (Convite c : lista) {
            model.addRow(new Object[]{
                    c.getId(), c.getChurrascoId(), c.getStatus(), c.getMensagem()
            });
        }
    }

    private String getSelecionado() {
        int row = table.getSelectedRow();
        if (row < 0) return null;
        return String.valueOf(model.getValueAt(row, 0));
    }

    private void aceitar() {
        String id = getSelecionado();
        if (id == null) {
            JOptionPane.showMessageDialog(this, "Selecione um convite.");
            return;
        }

        try {
            conviteController.aceitarConvite(id);
            JOptionPane.showMessageDialog(this, "Convite aceito!");
            carregar();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void recusar() {
        String id = getSelecionado();
        if (id == null) {
            JOptionPane.showMessageDialog(this, "Selecione um convite.");
            return;
        }

        try {
            conviteController.recusarConvite(id);
            JOptionPane.showMessageDialog(this, "Convite recusado.");
            carregar();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
}
