package ui.swing.panels;

import com.churrascoapp.app.AppContext;
import com.churrascoapp.controller.ParticipacaoController;
import com.churrascoapp.model.Participacao;
import com.churrascoapp.model.Usuario;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class MinhasParticipacoesPanel extends JPanel {

    private final Usuario usuario;
    private final ParticipacaoController participacaoController;

    private JTable table;
    private DefaultTableModel model;

    public MinhasParticipacoesPanel(Usuario usuario) {
        this.usuario = usuario;
        this.participacaoController = AppContext.get().participacoes();

        setLayout(new BorderLayout(8,8));

        JButton atualizarBtn = new JButton("Atualizar");
        JButton cancelarBtn  = new JButton("Cancelar participação");

        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT));
        top.add(atualizarBtn);
        top.add(cancelarBtn);

        add(top, BorderLayout.NORTH);

        model = new DefaultTableModel(
                new String[]{"ID", "Churrasco", "Status", "Valor Pago", "Pagou?"}, 0
        ) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(model);

        add(new JScrollPane(table), BorderLayout.CENTER);

        atualizarBtn.addActionListener(e -> carregar());
        cancelarBtn.addActionListener(e -> cancelar());

        carregar();
    }

    private void carregar() {
        model.setRowCount(0);

        // >>>>>>> TRATAMENTO DO ID NULO AQUI <<<<<<<<
        if (usuario.getId() == null) {
            JOptionPane.showMessageDialog(
                    this,
                    "Seu usuário não possui ID cadastrado no sistema.\n" +
                            "Por isso não é possível listar as participações automaticamente.\n\n" +
                            "Para usar essa funcionalidade, o usuário precisa ter um UUID salvo.",
                    "ID do usuário ausente",
                    JOptionPane.INFORMATION_MESSAGE
            );
            return;
        }

        List<Participacao> lista =
                participacaoController.listarPorUsuario(usuario.getId().toString());

        for (Participacao p : lista) {
            model.addRow(new Object[]{
                    p.getId(), p.getChurrascoId(), p.getStatus(),
                    p.getValorPago(), p.isPagamentoConfirmado()
            });
        }
    }

    private String getSelecionado() {
        int row = table.getSelectedRow();
        if (row < 0) return null;
        return String.valueOf(model.getValueAt(row, 0));
    }

    private void cancelar() {
        String id = getSelecionado();
        if (id == null) {
            JOptionPane.showMessageDialog(this, "Selecione uma participação.");
            return;
        }

        try {
            participacaoController.cancelar(id);
            JOptionPane.showMessageDialog(this, "Participação cancelada.");
            carregar();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
}
