
Projeto Java gerado automaticamente a partir do diagrama de classes fornecido.

Estrutura de pacotes:
- com.churrascoapp.model
- com.churrascoapp.dao
- com.churrascoapp.service
- com.churrascoapp.controller
- com.churrascoapp.utils
- com.churrascoapp.app (Main)

Como compilar (maven):
  mvn package
Como rodar:
  java -cp target/churrasco-app-1.0-SNAPSHOT.jar com.churrascoapp.app.MainApp

Arquivos CSV serão salvos em /data dentro da pasta do projeto.
