package com.churrascoapp.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import com.churrascoapp.dao.CompraDAO;
import com.churrascoapp.model.Carrinho;
import com.churrascoapp.model.Churrasco;
import com.churrascoapp.model.Compra;
import com.churrascoapp.model.ItemCarrinho;
import com.churrascoapp.utils.UUIDUtil;

/**
 * Service para gerenciamento de carrinho de compras.
 * Conforme diagrama de classes - artefatos_astah_v3
 */
public class CarrinhoService {
    private final CompraDAO compraDAO;
    private final ChurrascoService churrascoService;
    private final Map<String, Carrinho> carrinhos; // carrinhoId -> Carrinho (em memória)

    public CarrinhoService(CompraDAO compraDAO, ChurrascoService churrascoService) {
        this.compraDAO = compraDAO;
        this.churrascoService = churrascoService;
        this.carrinhos = new HashMap<>();
    }

    /**
     * Cria novo carrinho para usuário
     * @param usuarioId ID do usuário
     * @return Carrinho criado
     */
    public Carrinho criarCarrinho(String usuarioId) {
        UUID id = UUIDUtil.randomId();
        Carrinho carrinho = new Carrinho(id, UUID.fromString(usuarioId));
        carrinhos.put(id.toString(), carrinho);
        return carrinho;
    }

    /**
     * Busca carrinho por ID
     * @param carrinhoId ID do carrinho
     * @return Carrinho ou null
     */
    public Carrinho buscarCarrinho(String carrinhoId) {
        return carrinhos.get(carrinhoId);
    }

    /**
     * Adiciona item ao carrinho
     * @param carrinhoId ID do carrinho
     * @param item Item a ser adicionado
     * @return true se foi adicionado
     */
    public boolean adicionarItem(String carrinhoId, ItemCarrinho item) {
        Carrinho carrinho = carrinhos.get(carrinhoId);
        if (carrinho == null) {
            return false;
        }
        carrinho.getItens().add(item);
        return true;
    }

    /**
     * Remove item do carrinho
     * @param carrinhoId ID do carrinho
     * @param itemId ID do item
     * @return true se foi removido
     */
    public boolean removerItem(String carrinhoId, String itemId) {
        Carrinho carrinho = carrinhos.get(carrinhoId);
        if (carrinho == null) {
            return false;
        }
        return carrinho.getItens().removeIf(item -> item.getId().equals(UUID.fromString(itemId)));
    }

    /**
     * Lista todos os itens do carrinho
     * @param carrinhoId ID do carrinho
     * @return Lista de itens
     */
    public List<ItemCarrinho> listarItens(String carrinhoId) {
        Carrinho carrinho = carrinhos.get(carrinhoId);
        if (carrinho == null) {
            return new ArrayList<>();
        }
        return carrinho.getItens();
    }

    /**
     * Calcula total do carrinho
     * @param carrinhoId ID do carrinho
     * @return Valor total
     */
    public double calcularTotal(String carrinhoId) {
        Carrinho carrinho = carrinhos.get(carrinhoId);
        if (carrinho == null) {
            return 0.0;
        }
        return carrinho.calcularTotal();
    }

    /**
     * Limpa carrinho
     * @param carrinhoId ID do carrinho
     * @return true se foi limpo
     */
    public boolean limparCarrinho(String carrinhoId) {
        Carrinho carrinho = carrinhos.get(carrinhoId);
        if (carrinho == null) {
            return false;
        }
        carrinho.getItens().clear();
        return true;
    }

    /**
     * Finaliza compra convertendo carrinho em compras
     * @param carrinhoId ID do carrinho
     * @param churrascoId ID do churrasco
     * @return ID da primeira compra criada ou null
     */
    public String finalizarCompra(String carrinhoId, String churrascoId) {
        Carrinho carrinho = carrinhos.get(carrinhoId);
        if (carrinho == null || carrinho.getItens().isEmpty()) {
            return null;
        }

        String primeiraCompraId = null;
        String dataAtual = LocalDate.now().toString();

        // Converte cada item do carrinho em uma compra
        for (ItemCarrinho item : carrinho.getItens()) {
            UUID compraId = UUIDUtil.randomId();
            if (primeiraCompraId == null) {
                primeiraCompraId = compraId.toString();
            }

            // Busca informações do churrasco para obter o título/nome
            Churrasco churrasco = churrascoService.buscar(churrascoId);
            String nomeItem = churrasco != null ? churrasco.getTitulo() : "Item " + churrascoId;

            Compra compra = new Compra();
            compra.setId(compraId);
            compra.setChurrascoId(UUID.fromString(churrascoId));
            compra.setItem(nomeItem);
            compra.setQuantidade(item.getQuantidade());
            compra.setValor(item.getPrecoUnitario() * item.getQuantidade());
            compra.setData(dataAtual);

            compraDAO.adicionar(compra);
        }

        // Limpa carrinho após finalizar
        carrinho.getItens().clear();
        carrinhos.remove(carrinhoId);

        return primeiraCompraId;
    }

    /**
     * Atualiza quantidade de item no carrinho
     * @param carrinhoId ID do carrinho
     * @param itemId ID do item
     * @param novaQuantidade Nova quantidade
     * @return true se foi atualizado
     */
    public boolean atualizarQuantidade(String carrinhoId, String itemId, int novaQuantidade) {
        Carrinho carrinho = carrinhos.get(carrinhoId);
        if (carrinho == null) {
            return false;
        }

        for (ItemCarrinho item : carrinho.getItens()) {
            if (item.getId().equals(UUID.fromString(itemId))) {
                item.setQuantidade(novaQuantidade);
                return true;
            }
        }
        return false;
    }
}
