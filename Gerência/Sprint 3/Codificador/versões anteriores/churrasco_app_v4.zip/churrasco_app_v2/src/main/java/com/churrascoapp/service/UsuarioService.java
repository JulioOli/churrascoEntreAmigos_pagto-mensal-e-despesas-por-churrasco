package com.churrascoapp.service;

import com.churrascoapp.dao.UsuarioDAO;
import com.churrascoapp.model.Usuario;

import java.util.UUID;

public class UsuarioService {

    private final UsuarioDAO dao;

    public UsuarioService(UsuarioDAO dao) {
        this.dao = dao;
    }

    /**
     * Registra um novo usuário, garantindo:
     *  - nome, email, senha e tipo não vazios
     *  - e-mail único
     *  - UUID gerado
     */
    public Usuario registrar(String nome, String email, String senha, String tipo) {
        if (nome == null || nome.isBlank()) {
            throw new IllegalArgumentException("Nome é obrigatório.");
        }
        if (email == null || email.isBlank()) {
            throw new IllegalArgumentException("E-mail é obrigatório.");
        }
        if (senha == null || senha.isBlank()) {
            throw new IllegalArgumentException("Senha é obrigatória.");
        }
        if (tipo == null || tipo.isBlank()) {
            throw new IllegalArgumentException("Tipo/Papel é obrigatório.");
        }

        // Verifica se já existe usuário com mesmo e-mail
        Usuario existente = dao.buscarPorEmail(email);
        if (existente != null) {
            throw new IllegalStateException("E-mail já cadastrado.");
        }

        Usuario u = new Usuario(
                UUID.randomUUID(),
                nome,
                email,
                senha,
                tipo
        );

        boolean ok = dao.adicionar(u);
        if (!ok) {
            throw new RuntimeException("Falha ao cadastrar usuário.");
        }

        return u;
    }

    /**
     * Autentica usuário por e-mail + senha.
     * Retorna o objeto completo (com id preenchido) ou null se inválido.
     */
    public Usuario autenticar(String email, String senha) {
        if (email == null || email.isBlank()) return null;
        if (senha == null) senha = "";

        Usuario u = dao.buscarPorEmail(email);
        if (u == null) return null;

        String s = u.getSenha() == null ? "" : u.getSenha();
        return s.equals(senha) ? u : null;
    }

    /**
     * Busca usuário por nome OU e-mail (exato, case-insensitive).
     * Usado para convites via nome.
     */
    public Usuario buscarPorNomeOuEmail(String termo) {
        if (termo == null || termo.isBlank()) return null;
        return dao.buscarPorNomeOuEmail(termo.trim());
    }
}
